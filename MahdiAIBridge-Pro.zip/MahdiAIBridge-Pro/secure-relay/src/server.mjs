import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
const app=express(); app.use(helmet()); app.use(express.json({limit:"2mb"}));
app.use(rateLimit({windowMs:60_000,max:60,standardHeaders:true,legacyHeaders:false}));
const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
const model=process.env.OPENAI_MODEL || "gpt-6-luna";
app.post("/v1/assistant",async(req,res)=>{
 try{
  if(req.header("x-device-token")!==process.env.DEVICE_TOKEN)return res.status(401).json({error:"unauthorized"});
  const input=req.body?.input;
  if(typeof input!=="string"||input.length>12000)return res.status(400).json({error:"invalid_input"});
  const response=await client.responses.create({
   model,input,
   tools:[{type:"web_search"}]
  });
  res.json({output:response.output_text});
 }catch(e){res.status(500).json({error:"upstream_failure"});}
});
app.get("/health",(_,res)=>res.json({ok:true}));
app.listen(Number(process.env.PORT||8787),"0.0.0.0");
