# Professional architecture

POCO Android
→ Local command router
→ Permission/policy gate
→ Tool registry
→ Secure Relay
→ OpenAI Responses API + web search/tools
→ Structured plan
→ App-side validation
→ Confirmation for sensitive actions
→ Execution
→ Audit log

## Google
Gmail and Drive use OAuth 2.0. Tokens must be stored securely. Request the narrowest practical scopes. Google may require OAuth verification for sensitive/restricted scopes.

## Search
The relay should support multiple lawful search/data providers and fallback routing. “Best” is not hard-coded: criteria and weights come from the user's request, while the system exposes assumptions, evidence, uncertainty and trade-offs.

## Financial analysis
For purchases/investment-like comparisons, collect date-stamped prices, total cost, inflation/currency assumptions, warranty, maintenance and seller reliability. Never silently fabricate missing data.

## Security
Never put provider API keys in the APK. Use TLS, device authentication, rate limits, request IDs, replay protection, strict schemas, secret redaction, minimal logs and explicit confirmation for destructive actions.

## File access
Android Storage Access Framework gives access to user-selected documents/directories. It does not grant arbitrary access to private data of other apps. Android 11+ also restricts some paths such as Android/data and Android/obb.
