# Hard platform boundaries

1. The app cannot legitimately bypass Android sandboxing or another app's private storage.
2. Google OAuth requires user authorization and scopes.
3. Network availability, provider terms, regional restrictions and service outages cannot be guaranteed away.
4. Web search results are evidence, not automatic truth; sources need freshness and cross-checking.
5. Unknown binary files can be managed as files (list/copy/hash/open) but content interpretation requires a compatible parser.
6. Sensitive/destructive actions require an explicit confirmation gate in the app.
