plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace="com.mahdi.aibridge"; compileSdk=35
 defaultConfig { applicationId="com.mahdi.aibridge"; minSdk=26; targetSdk=35; versionCode=70; versionName="7.0-pro" }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.appcompat:appcompat:1.7.0")
 implementation("com.google.android.material:material:1.12.0")
 implementation("androidx.activity:activity-ktx:1.10.0")
 implementation("com.google.android.gms:play-services-auth:21.3.0")
}
