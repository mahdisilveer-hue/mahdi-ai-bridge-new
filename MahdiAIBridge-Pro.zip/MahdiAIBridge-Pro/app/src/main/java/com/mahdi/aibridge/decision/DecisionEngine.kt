package com.mahdi.aibridge.decision
import com.mahdi.aibridge.core.*
object DecisionEngine {
 fun framework(question:String, priorities:Map<String,Double>):String{
  val p=priorities.entries.sortedByDescending{it.value}.joinToString("، "){it.key}
  return "سؤال: $question\nمعیارهای با اولویت بالاتر: $p\n" +
    "روش: داده تازه → اعتبار منبع → هزینه کل → کیفیت → ریسک → سناریوها → تحلیل حساسیت → نتیجه مشروط."
 }
}
