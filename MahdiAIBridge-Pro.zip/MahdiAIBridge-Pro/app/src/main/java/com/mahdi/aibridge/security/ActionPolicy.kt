package com.mahdi.aibridge.security
import com.mahdi.aibridge.core.Risk
object ActionPolicy {
 fun requiresConfirmation(risk:Risk)=risk==Risk.SENSITIVE || risk==Risk.DESTRUCTIVE
 fun sanitize(s:String)=s.replace(Regex("(?i)(api[_-]?key|authorization|bearer|refresh[_-]?token)\\s*[:=]\\s*\\S+"),"$1=[REDACTED]")
}
