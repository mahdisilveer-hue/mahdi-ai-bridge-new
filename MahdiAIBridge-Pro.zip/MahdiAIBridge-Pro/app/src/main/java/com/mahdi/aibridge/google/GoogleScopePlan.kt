package com.mahdi.aibridge.google
object GoogleScopePlan {
 // Start narrow. Expand only when a requested operation actually needs it.
 const val DRIVE_FILE="https://www.googleapis.com/auth/drive.file"
 const val DRIVE_METADATA="https://www.googleapis.com/auth/drive.metadata.readonly"
 const val GMAIL_READONLY="https://www.googleapis.com/auth/gmail.readonly"
 const val GMAIL_COMPOSE="https://www.googleapis.com/auth/gmail.compose"
}
