package com.mahdi.aibridge.security
import android.content.Context
class AuditLog(ctx:Context){
 private val p=ctx.getSharedPreferences("audit",Context.MODE_PRIVATE)
 fun add(event:String){ val old=p.getString("events","")?:""; p.edit().putString("events",(old+"\n"+System.currentTimeMillis()+" "+ActionPolicy.sanitize(event)).takeLast(50000)).apply() }
 fun read()=p.getString("events","")?:""
}
