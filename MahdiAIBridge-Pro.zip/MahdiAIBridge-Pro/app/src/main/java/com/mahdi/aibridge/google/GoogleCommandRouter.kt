package com.mahdi.aibridge.google
object GoogleCommandRouter {
 fun route(text:String):String=when{
  Regex("(?i)\\b(ایمیل|جیمیل|gmail)\\b").containsMatchIn(text)->"GMAIL"
  Regex("(?i)(گوگل\\s*درایو|drive|درایو)").containsMatchIn(text)->"DRIVE"
  else->"NONE"
 }
}
