package com.mahdi.aibridge.ai
import com.mahdi.aibridge.core.*
import com.mahdi.aibridge.security.ActionPolicy
object CommandPlanner {
 fun localPlan(text:String):Plan{
  val t=text.trim()
  val risk=when{
   Regex("(?i)(حذف|پاک|ارسال|انتشار|اشتراک|تغییر رمز|جابه.?جا)").containsMatchIn(t)->Risk.SENSITIVE
   else->Risk.READ_ONLY
  }
  val calls=mutableListOf<ToolCall>()
  when{
   Regex("(?i)(جیمیل|ایمیل|gmail)").containsMatchIn(t)->calls+=ToolCall("gmail.search",mapOf("query" to t),risk)
   Regex("(?i)(درایو|drive)").containsMatchIn(t)->calls+=ToolCall("drive.search",mapOf("query" to t),risk)
   Regex("(?i)(فایل|پوشه)").containsMatchIn(t)->calls+=ToolCall("files.search",mapOf("query" to t),risk)
  }
  if(calls.isEmpty()) calls+=ToolCall("web.research",mapOf("query" to t),Risk.READ_ONLY)
  return Plan("natural_language_command","ابتدا ابزار مناسب انتخاب و سپس نتیجه اعتبارسنجی می‌شود.",calls,calls.any{ActionPolicy.requiresConfirmation(it.risk)})
 }
}
