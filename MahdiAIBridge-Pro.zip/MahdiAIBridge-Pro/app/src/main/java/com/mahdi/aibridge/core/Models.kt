package com.mahdi.aibridge.core
enum class Risk { READ_ONLY, LOW, SENSITIVE, DESTRUCTIVE }
data class ToolCall(val name:String,val args:Map<String,String>,val risk:Risk)
data class Plan(val intent:String,val explanation:String,val calls:List<ToolCall>,val needsConfirmation:Boolean)
data class Evidence(val source:String,val title:String,val url:String?,val date:String?,val confidence:Double)
data class Decision(val question:String,val assumptions:List<String>,val options:List<String>,val evidence:List<Evidence>,val tradeoffs:List<String>,val recommendationRationale:String)
