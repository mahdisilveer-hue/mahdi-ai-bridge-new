package com.mahdi.aibridge.ui
import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.*
import com.mahdi.aibridge.ai.CommandPlanner
import com.mahdi.aibridge.security.AuditLog
class MainActivity:Activity(){
 private lateinit var input:EditText; private lateinit var out:TextView
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,24,24,24)}
  val title=TextView(this).apply{text="Mahdi AI Bridge Pro";textSize=26f}
  input=EditText(this).apply{hint="فرمان فارسی؛ مثلاً: ایمیل‌های امروز را بررسی کن"}
  val run=Button(this).apply{text="تحلیل و اجرا"}
  val voice=Button(this).apply{text="🎙 فرمان صوتی"}
  val access=Button(this).apply{text="📁 انتخاب پوشه‌های قابل مدیریت"}
  out=TextView(this).apply{text="آماده";textSize=16f}
  run.setOnClickListener{ val p=CommandPlanner.localPlan(input.text.toString()); out.text="هدف: ${p.intent}\n${p.explanation}\nابزارها: ${p.calls.joinToString{it.name}}\nتأیید لازم: ${p.needsConfirmation}"; AuditLog(this).add("PLAN ${input.text}") }
  voice.setOnClickListener{startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE,"fa-IR"),77)}
  access.setOnClickListener{com.mahdi.aibridge.files.FileTool.chooseDirectory(this)}
  box.addView(title);box.addView(input);box.addView(run);box.addView(voice);box.addView(access);box.addView(out);setContentView(box)
 }
 override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==77&&c==RESULT_OK)input.setText(d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty())}
}
