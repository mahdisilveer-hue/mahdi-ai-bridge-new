package com.mahdi.aibridge.files
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
object FileTool {
 fun chooseDirectory(ctx:Context){ ctx.startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)) }
 fun uriSummary(uri:Uri)=DocumentsContract.getTreeDocumentId(uri)
}
